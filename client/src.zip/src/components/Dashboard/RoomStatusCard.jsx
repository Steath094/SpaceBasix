import React from 'react';
import { useRecoilValueLoadable } from 'recoil';
import { roomListAtom } from '../../store/Room';

const RoomStatusCard = () => {
  const roomListLoadable = useRecoilValueLoadable(roomListAtom);

  function getRoomStatusFromRoomList(roomList) {
    const roomStatus = {
      occupiedRooms: {
        count: 0,
        clean: 0,
        dirty: 0,
        inspected: 0,
      },
      available: {
        count: 0,
        clean: 0,
        dirty: 0,
        inspected: 0,
      }
    };

    roomList.forEach(room => {
      const isOccupied = room.occupied > 0;

      if (isOccupied) {
        roomStatus.occupiedRooms.count++;
        if (room.cleanlinessStatus === "CLEAN") {
          roomStatus.occupiedRooms.clean++;
        } else {
          roomStatus.occupiedRooms.dirty++;
        }
        if (room.inspectionCount > 0) {
          roomStatus.occupiedRooms.inspected++;
        }
      } else {
        roomStatus.available.count++;
        if (room.cleanlinessStatus === "CLEAN") {
          roomStatus.available.clean++;
        } else {
          roomStatus.available.dirty++;
        }
        if (room.inspectionCount > 0) {
          roomStatus.available.inspected++;
        }
      }
    });

    return roomStatus;
  }

  if (roomListLoadable.state === 'loading') {
    return (
      <div className="rounded-xl p-6 bg-white w-3/4 shadow-md animate-pulse">
        <div className="h-6 bg-gray-300 rounded w-32 mb-6"></div>
        <div className="space-y-4">
          <div className="h-20 bg-gray-200 rounded"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (roomListLoadable.state === 'hasError') {
    return (
      <div className="rounded-xl p-6 bg-white w-3/4 shadow-md text-red-500">
        Error loading room status.
      </div>
    );
  }

  const roomList = roomListLoadable.contents;
  const roomStatus = getRoomStatusFromRoomList(roomList);

  return (
    <div className="rounded-xl p-6 bg-white w-3/4 shadow-md">
      <h3 className="text-lg font-semibold text-gray-800 mb-6">Room status</h3>

      <div className="grid grid-cols-2 gap-16">
        {/* Occupied Rooms */}
        <div>
          <div className="flex justify-between items-center font-medium text-gray-800 mb-4">
            <span>Occupied rooms</span>
            <span>{roomStatus.occupiedRooms.count}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 py-1">
            <span>Clean</span>
            <span className="text-gray-800">{roomStatus.occupiedRooms.clean}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 py-1">
            <span>Dirty</span>
            <span className="text-gray-800">{roomStatus.occupiedRooms.dirty}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 py-1">
            <span>Inspected</span>
            <span className="text-gray-800">{roomStatus.occupiedRooms.inspected}</span>
          </div>
        </div>

        {/* Available Rooms */}
        <div>
          <div className="flex justify-between items-center font-medium text-gray-800 mb-4">
            <span>Available rooms</span>
            <span>{roomStatus.available.count}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 py-1">
            <span>Clean</span>
            <span className="text-gray-800">{roomStatus.available.clean}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 py-1">
            <span>Dirty</span>
            <span className="text-gray-800">{roomStatus.available.dirty}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 py-1">
            <span>Inspected</span>
            <span className="text-gray-800">{roomStatus.available.inspected}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoomStatusCard;
