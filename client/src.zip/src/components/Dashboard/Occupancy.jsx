import React from 'react';
import { PieChart, Pie, Cell } from 'recharts';
import { ExternalLink } from 'lucide-react';
import { roomListAtom } from '../../store/Room';
import { useRecoilValueLoadable } from 'recoil';

const COLORS = ['#00FFFF', '#2c2c2c']; // Neon cyan & dark grey

const OccupancyCard = () => {
  const roomListLoadable = useRecoilValueLoadable(roomListAtom);

  function getRoomOccupancyChartData(roomList) {
    let occupiedCount = 0;
    let emptyCount = 0;

    roomList.forEach(room => {
      if (room.occupied > 0) {
        occupiedCount++;
      } else {
        emptyCount++;
      }
    });

    return [
      { name: 'Occupied', value: occupiedCount },
      { name: 'Empty', value: emptyCount }
    ];
  }

  if (roomListLoadable.state === 'loading') {
    return (
      <div className="bg-white text-black p-6 rounded-2xl shadow-md animate-pulse">
        <div className="h-6 w-32 bg-gray-300 rounded mb-4"></div>
        <div className="h-[200px] w-full bg-gray-200 rounded"></div>
      </div>
    );
  }

  if (roomListLoadable.state === 'hasError') {
    return (
      <div className="bg-white text-red-500 p-6 rounded-2xl shadow-md">
        <p>Error loading occupancy data.</p>
      </div>
    );
  }

  const roomList = roomListLoadable.contents;
  const data = getRoomOccupancyChartData(roomList);
  const total = data.reduce((sum, item) => sum + item.value, 0);
  const occupied = data.find(d => d.name === 'Occupied')?.value || 0;
  const percent = total > 0 ? Math.round((occupied / total) * 100) : 0;

  return (
    <div className="bg-white text-black p-6 rounded-2xl shadow-md relative">
      <div className="flex items-center gap-1 mb-4">
        <h2 className="text-xl font-semibold">Occupancy</h2>
        <ExternalLink size={14} />
      </div>

      <div className="flex justify-center items-center relative">
        <PieChart width={200} height={200}>
          <Pie
            data={data}
            innerRadius={70}
            outerRadius={90}
            startAngle={180}
            endAngle={-180}
            paddingAngle={0}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
        </PieChart>
        <div className="absolute text-black text-2xl font-bold">{percent}%</div>
      </div>
    </div>
  );
};

export default OccupancyCard;
