import React from 'react'
import FaqSection from './FaqSection'
import { useRecoilValue } from 'recoil'
import { userStatusAtom } from '../store/userStatusAtom'

function HomeWithoutLogin() {
    const userStatus = useRecoilValue(userStatusAtom)
    
  return (
    <div>
        <div className='bg-[#F8F8F8] flex px-24 py-10 '>
        <div className='w-1/2'>
            <div className='flex flex-col gap-5'>
                <h1 className='font-sans font-bold text-6xl leading-[140%] tracking-tighter'>Manage Your Hostel
                Effortlessly, Anytime, and Anywhere.</h1>
                <p className='font-sans text-xl'><span className='font-bold'>Smart Hostel Management</span> made simple. Seamlessly manage rooms, student data, fees, and complaints — all in one place. Empower wardens and students with a smooth, hassle-free experience.</p>
                {userStatus.islogin===false && <button className='border-2 border-[#2489D3] text-xl font-sans bg-[#2489D3] text-white rounded-[50px] px-10 py-4 cursor-pointer hover:bg-[#1d6ea9] hover:outline-[3px] w-80'>Register Your Hostel</button>}
            </div>
            <div className="flex justify-around py-8 bg-gray-50">
                <div className="text-center">
                    <h2 className="text-yellow-500 text-3xl font-bold">50+</h2>
                    <p className="text-black font-medium">Hostels Managed</p>
                </div>

                <div className="text-center">
                    <h2 className="text-blue-500 text-3xl font-bold">2000+</h2>
                    <p className="text-black font-medium">Students Registered</p>
                </div>

                <div className="text-center">
                    <h2 className="text-orange-500 text-3xl font-bold">500+</h2>
                    <p className="text-black font-medium">Complaints Resolved</p>
                </div>
            </div>
        </div>
        <div className='flex w-1/2 justify-center items-center rounded-2xl'>
            <img className='' src="/Images/hostel.png" alt="hostel" />
            </div>
    </div>
    <div className='bg-[#F8F8F8] w-full pb-16'>
    <FaqSection/>
    </div>
    </div>
  )
}

export default HomeWithoutLogin