import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { userStatusAtom } from '../store/userStatusAtom';
import { useRecoilState, useRecoilValue, useSetRecoilState } from 'recoil';
import { profileAtom } from '../store/profileAtom';
function NavBar() {
  const navigate = useNavigate()
  const [userStatus,setUserStatus] = useRecoilState(userStatusAtom)
  const setProfile = useSetRecoilState(profileAtom)
      const authStatus = userStatus.islogin;
  const navItems = [
    {
        name: "Dashboard",
        slug: "/admin-dashboard",
        active: authStatus && userStatus.role=='admin'
    },
    {
        name: "Dashboard",
        slug: "/student-dashboard",
        active: authStatus && userStatus.role=='student'
    },
    {
        name: "Rooms",
        slug: "/rooms",
        active: authStatus && userStatus.role=='admin',
    },
    {
      name: "Students",
      slug: "/students",
      active: authStatus && userStatus.role=='admin',
  },
    {
        name: "Complaints",
        slug: "/complaints",
        active: authStatus && userStatus.role=='admin',
    },
    
]
    const handleLogout = () =>{
        const user = {
            islogin: false,
            role: null
        }
        setUserStatus(user)
        setProfile({})
        localStorage.setItem("userStatus", JSON.stringify(user));

        localStorage.setItem("profile", JSON.stringify({}));
        navigate('/')
    }
  return (
    <nav className='flex justify-between items-center px-12 py-4'>
        <div className='flex'>
            {/* <Link to={'/'}>SpaceBasix</Link> */}
            <Link to={'/'} className='flex text-center justify-center items-center gap-4 text-[#2489D3] font-sans font-bold text-2xl' href="/">
            <div className='w-12 h-12'><img className='w-full h-full' src="Images/logo.png" alt="logo" /></div><span className='hover:border-b-2'>SpaceBasix</span></Link>
        </div>  
        {!authStatus && <div className='flex gap-4'>
            <button onClick={()=>navigate('login')} className='border-2 border-[#2489D3] text-xl font-sans text-[#2489D3] rounded-[50px] px-10 py-2.5 cursor-pointer  hover:outline-[3px]'>Login</button>
            <button onClick={()=>navigate('signup')} className='border-2 border-[#2489D3] text-xl font-sans bg-[#2489D3] text-white rounded-[50px] px-10 py-2.5 cursor-pointer hover:bg-[#1d6ea9] hover:outline-[3px]' >Sign Up</button>
        </div>}
        {authStatus && 
        <ul className='hidden md:flex ml-auto space-x-4'>
        {navItems.map((item) =>
            item.active ? (
                <li key={item.name}>
                    <button
                        onClick={() => navigate(item.slug)}
                        className='inline-block px-6 py-2 duration-200 hover:bg-blue-100 rounded-full text-black text-inter hover:text-black'
                    >
                        {item.name}
                    </button>
                </li>
            ) : null
        )}
</ul>}
      {authStatus && <button onClick={handleLogout} className='border-2 ml-4 border-[#2489D3] text-xl font-sans bg-[#2489D3] text-white rounded-[50px] px-8 py-2 cursor-pointer hover:bg-[#1d6ea9] hover:outline-[3px]' >Logout</button>}
    </nav>
  )
}

export default NavBar