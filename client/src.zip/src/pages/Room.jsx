import React, { useState } from 'react';
import { useRecoilValueLoadable } from 'recoil';
import { roomListAtom } from '../store/Room';
import { Link, useNavigate } from 'react-router-dom';
import Loader from '../components/Loader'; // Make sure this path is correct

const statusColors = {
  Available: 'text-blue-600 bg-blue-100',
  Occupied: 'text-red-600 bg-red-100',
  Reserved: 'text-green-600 bg-green-100',
  Waitlist: 'text-yellow-600 bg-yellow-100',
  Blocked: 'text-gray-600 bg-gray-200',
};

export default function Room() {
  const roomListLoadable = useRecoilValueLoadable(roomListAtom);
  const [filter, setFilter] = useState('All');
  const navigate = useNavigate();

  function transformRoomListToRooms(roomList) {
    return roomList.map((room) => ({
      id: room.id,
      number: `#${room.roomNumber}`,
      type: room.capacity === 1 ? 'Single bed' : 'Double bed',
      capacity: room.capacity,
      occupied: room.occupied,
      facility: room.description,
      status: room.occupied >= room.capacity ? 'Occupied' : 'Available',
    }));
  }

  if (roomListLoadable.state === 'loading') {
    return (
      <div className="m-6 border-2 h-screen border-gray-200 rounded-xl p-4 bg-white shadow-md">
        <Loader />
        <div className="animate-pulse space-y-4 mt-6">
          {[...Array(5)].map((_, idx) => (
            <div key={idx} className="h-6 bg-gray-200 rounded w-full"></div>
          ))}
        </div>
      </div>
    );
  }

  if (roomListLoadable.state === 'hasError') {
    return (
      <div className="m-6 border-2 h-screen border-gray-200 rounded-xl p-4 bg-white shadow-md flex items-center justify-center text-red-600">
        Error loading room list. Please try again later.
      </div>
    );
  }

  const roomList = roomListLoadable.contents;
  const rooms = transformRoomListToRooms(roomList);

  const filteredRooms = rooms.filter((room) => {
    if (filter === 'Available') return room.status === 'Available';
    if (filter === 'Occupied') return room.status === 'Occupied';
    return true;
  });

  return (
    <div className="m-6 border-2 h-screen border-gray-200 rounded-xl p-4 bg-white shadow-md">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Room</h2>
        <button
          onClick={() => navigate('/add-room')}
          className="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700"
        >
          Add room
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex space-x-4 mb-4">
        <button
          className={`${
            filter === 'All' ? 'text-blue-600 bg-blue-100' : 'text-gray-600'
          } font-medium border border-blue-600 px-3 py-1 rounded-full`}
          onClick={() => setFilter('All')}
        >
          All room ({rooms.length})
        </button>
        <button
          className={`${
            filter === 'Available' ? 'text-blue-600 bg-blue-100' : 'text-gray-600'
          } border px-3 py-1 rounded-full hover:bg-gray-100`}
          onClick={() => setFilter('Available')}
        >
          Available ({rooms.filter((r) => r.status === 'Available').length})
        </button>
        <button
          className={`${
            filter === 'Occupied' ? 'text-blue-600 bg-blue-100' : 'text-gray-600'
          } border px-3 py-1 rounded-full hover:bg-gray-100`}
          onClick={() => setFilter('Occupied')}
        >
          Occupied ({rooms.filter((r) => r.status === 'Occupied').length})
        </button>
      </div>

      {/* Room List or No Rooms Message */}
      {filteredRooms.length === 0 ? (
        <div className="p-6 text-gray-600">No {filter.toLowerCase()} rooms available.</div>
      ) : (
        <div className="overflow-y-auto max-h-[450px] border-t border-gray-200">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-white z-10">
              <tr className="text-gray-500 border-b">
                <th className="p-2">Room number</th>
                <th className="p-2">Bed type</th>
                <th className="p-2">Capacity</th>
                <th className="p-2">Occupied</th>
                <th className="p-2">Room facility</th>
                <th className="p-2">Status</th>
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {filteredRooms.map((room) => (
                <tr
                  onClick={() => navigate(`/room/${room.id}`)}
                  key={room.id}
                  className="border-b hover:bg-gray-50 transition"
                >
                  <td className="p-2 font-medium text-gray-800">{room.number}</td>
                  <td className="p-2">{room.type}</td>
                  <td className="p-2">{room.capacity}</td>
                  <td className="p-2">{room.occupied}</td>
                  <td className="p-2">{room.facility}</td>
                  <td className="p-2">
                    <span
                      className={`text-xs font-semibold px-2 py-1 rounded-full ${statusColors[room.status]}`}
                    >
                      {room.status}
                    </span>
                  </td>
                  <td className="p-2 text-right text-gray-400">
                    <Link to={`/room/${room.id}`} className="text-blue-600 hover:text-blue-700">
                      ⋮
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
