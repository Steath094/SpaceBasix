import React, { Suspense } from 'react';
import OverView from '../components/Dashboard/OverView';
import RoomStatusCard from '../components/Dashboard/RoomStatusCard';
import OccupancyCard from '../components/Dashboard/Occupancy';
import ComplaintsCard from '../components/Dashboard/ComplaintCard';
import StudentUpdateCard from '../components/Dashboard/StudentUpdateCard';
import { Loader } from 'lucide-react';


function AdminDashboard() {
  return (
    <Suspense fallback={<Loader />}>
      <div className="grid grid-cols-6 bg-[#FAF9F6] p-10">
        <div className="col-span-4 flex flex-col gap-4">
          <OverView />
          <div className="flex w-full gap-2">
            <RoomStatusCard />
            <OccupancyCard />
          </div>
          <ComplaintsCard />
        </div>
        <div className="col-span-2">
          <StudentUpdateCard />
        </div>
      </div>
    </Suspense>
  );
}

export default AdminDashboard;
