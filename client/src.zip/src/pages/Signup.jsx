import React, { useState, useRef } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useSetRecoilState } from "recoil";
import { profileAtom } from "../store/profileAtom";
import { userStatusAtom } from "../store/userStatusAtom";

const Signup = () => {
  const formRef = useRef({
    name: "",
    email: "",
    password: "",
    hostelName: "",
    institute: "",
  });

  const [formErrors, setFormErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const setProfile = useSetRecoilState(profileAtom);
  const setUserStatus = useSetRecoilState(userStatusAtom);
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    formRef.current[name] = value;
    setFormErrors((prev) => ({ ...prev, [name]: "" })); // Reset error on change
  };

  const validateForm = () => {
    const errors = {};
    if (!formRef.current.name) errors.name = "Name is required";
    if (!formRef.current.email) errors.email = "Email is required";
    if (!formRef.current.password) errors.password = "Password is required";
    if (!formRef.current.hostelName) errors.hostelName = "Hostel Name is required";
    if (!formRef.current.institute) errors.institute = "Institute is required";
    return errors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate form
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setLoading(true); // Start loading

    const { name, email, password, hostelName, institute } = formRef.current;

    try {
      const response = await axios.post("http://localhost:8080/api/admin/register", {
        name,
        email,
        password,
        hostelName,
        institute,
      });

      // Assuming the backend returns the user's profile data upon successful registration
      const user = response.data;

      // Set the profileAtom and userStatusAtom with the user data
      setProfile(user);
      setUserStatus({
        islogin: true,
        role: "admin",
      });

      // Update localStorage with user profile and user status
      localStorage.setItem("profile", JSON.stringify(user));
      localStorage.setItem("userStatus", JSON.stringify({ islogin: true, role: "admin" }));

      // Redirect to the admin dashboard
      navigate("/admin-dashboard");
    } catch (error) {
      console.error("Error registering user", error);
      // You can add error handling here (e.g., show an alert or error message)
    } finally {
      setLoading(false); // Stop loading
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAF9F6]">
      <div className="bg-white shadow-md rounded-3xl p-8 flex w-full max-w-5xl">
        {/* Left form section */}
        <div className="w-1/2 pr-8">
          <h2 className="text-4xl font-bold text-gray-900 mb-8">Sign up</h2>
          <form onSubmit={handleSubmit}>
            {/* Name */}
            <div className="mb-4">
              <label className="block mb-1 text-gray-700">
                <i className="fas fa-user mr-2" />
                Your Name
              </label>
              <input
                type="text"
                name="name"
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Your Name"
              />
              {formErrors.name && <p className="text-red-500 text-sm">{formErrors.name}</p>}
            </div>

            {/* Email */}
            <div className="mb-4">
              <label className="block mb-1 text-gray-700">
                <i className="fas fa-envelope mr-2" />
                Your Email
              </label>
              <input
                type="email"
                name="email"
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Your Email"
              />
              {formErrors.email && <p className="text-red-500 text-sm">{formErrors.email}</p>}
            </div>

            {/* Password */}
            <div className="mb-4">
              <label className="block mb-1 text-gray-700">
                <i className="fas fa-lock mr-2" />
                Password
              </label>
              <input
                type="password"
                name="password"
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Password"
              />
              {formErrors.password && <p className="text-red-500 text-sm">{formErrors.password}</p>}
            </div>

            {/* Hostel Name */}
            <div className="mb-4">
              <label className="block mb-1 text-gray-700">
                <i className="fas fa-building mr-2" />
                Hostel Name
              </label>
              <input
                type="text"
                name="hostelName"
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Hostel Name"
              />
              {formErrors.hostelName && <p className="text-red-500 text-sm">{formErrors.hostelName}</p>}
            </div>

            {/* Institute */}
            <div className="mb-6">
              <label className="block mb-1 text-gray-700">
                <i className="fas fa-university mr-2" />
                Institute
              </label>
              <input
                type="text"
                name="institute"
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Institute"
              />
              {formErrors.institute && <p className="text-red-500 text-sm">{formErrors.institute}</p>}
            </div>

            {/* Terms */}
            <div className="mb-6 flex items-center">
              <input type="checkbox" className="mr-2" required />
              <label className="text-sm text-gray-600">
                I agree to all statements in{" "}
                <a href="#" className="text-blue-600 underline">
                  Terms of Service
                </a>
              </label>
            </div>

            {/* Register Button */}
            <button
              type="submit"
              className="w-1/3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
              disabled={loading}
            >
              {loading ? (
                <div className="animate-spin border-4 border-t-4 border-blue-600 rounded-full w-6 h-6 mx-auto"></div>
              ) : (
                "Register"
              )}
            </button>
          </form>
        </div>

        {/* Right illustration section */}
        <div className="w-1/2 flex flex-col items-center justify-center">
          <img
            src="/Images/signup-image.jpg" // Replace with your actual image
            alt="Signup illustration"
            className="w-3/4"
          />
          <a
            href="/login"
            className="mt-6 text-sm text-blue-700 underline hover:text-blue-900"
          >
            I am already a member!
          </a>
        </div>
      </div>
    </div>
  );
};

export default Signup;
